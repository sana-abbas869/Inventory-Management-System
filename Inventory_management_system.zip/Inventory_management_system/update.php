<select PartNo='NEW'>  
					<option value="">--- Select ---</option>  
					<?  
						mysql_connect ("localhost","root","");  
						mysql_select_db ("inventory");  
						$select="inventory";  
						if (isset ($select)&&$select!=""){  
						$select=$_POST ['NEW'];  
					}  
					?>  
					<?  
						$list=mysql_query("select PartNo from itemsentry order by PartNo");  
					while($row_list=mysql_fetch_assoc($list)){  
						?>  
							<option value="<? echo $row_list['PartNo']; ?>"
								<? if($row_list['PartNo']==$select){ echo "selected"; } ?>>  
												 <?echo $row_list['PartNo'];?>  
							</option>  
						<?  
						}  
						?>  
					</select> 