-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 04, 2022 at 06:30 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inventory`
--

-- --------------------------------------------------------

--
-- Table structure for table `issue`
--

CREATE TABLE `issue` (
  `IssueVoucherNo` int(20) NOT NULL,
  `PartNo` int(20) NOT NULL,
  `QuantityIssued` int(20) NOT NULL,
  `Issuedate` date NOT NULL,
  `Remarks` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `itemsentry`
--

CREATE TABLE `itemsentry` (
  `Project` varchar(200) DEFAULT NULL,
  `PartNo` int(50) NOT NULL,
  `Description` varchar(40) NOT NULL,
  `Supplierid` int(11) NOT NULL,
  `WarehouseId` int(11) NOT NULL,
  `Qty_held` int(11) NOT NULL,
  `Currency` text NOT NULL,
  `LastCurrentPrice` int(11) NOT NULL,
  `LastRecievedDate` date NOT NULL,
  `LastIssuedDate` date NOT NULL,
  `EntryDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `project`
--

CREATE TABLE `project` (
  `Projectname` varchar(40) NOT NULL,
  `ProjectDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `receipt`
--

CREATE TABLE `receipt` (
  `S/No` int(20) NOT NULL,
  `IssueVoucherNo` int(30) NOT NULL,
  `ReceiptNo` int(20) NOT NULL,
  `Date` date NOT NULL,
  `TotalPrice` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `requistion`
--

CREATE TABLE `requistion` (
  `S/No` int(11) NOT NULL,
  `Req_No` int(10) NOT NULL,
  `Req_Date` date NOT NULL,
  `PartNo` int(20) NOT NULL,
  `Qty_demand` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `shop`
--

CREATE TABLE `shop` (
  `ShopId` int(10) NOT NULL,
  `ShopName` text NOT NULL,
  `ShopAddress` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `SupplierId` int(10) NOT NULL,
  `CompanyName` varchar(50) NOT NULL,
  `Address` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `warehouse`
--

CREATE TABLE `warehouse` (
  `WareHouseId` int(10) NOT NULL,
  `WarehouseAddress` varchar(100) NOT NULL,
  `WarehouseName` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `issue`
--
ALTER TABLE `issue`
  ADD PRIMARY KEY (`IssueVoucherNo`),
  ADD KEY `partno_pk` (`PartNo`);

--
-- Indexes for table `itemsentry`
--
ALTER TABLE `itemsentry`
  ADD PRIMARY KEY (`PartNo`),
  ADD KEY `project_fk` (`Project`),
  ADD KEY `supplier_fk` (`Supplierid`),
  ADD KEY `warehouse_fk` (`WarehouseId`);

--
-- Indexes for table `project`
--
ALTER TABLE `project`
  ADD PRIMARY KEY (`Projectname`);

--
-- Indexes for table `receipt`
--
ALTER TABLE `receipt`
  ADD PRIMARY KEY (`ReceiptNo`),
  ADD UNIQUE KEY `Unique` (`S/No`),
  ADD KEY `Issue_fk` (`IssueVoucherNo`);

--
-- Indexes for table `requistion`
--
ALTER TABLE `requistion`
  ADD PRIMARY KEY (`Req_No`),
  ADD UNIQUE KEY `Unique` (`S/No`),
  ADD KEY `partno_fk` (`PartNo`);

--
-- Indexes for table `shop`
--
ALTER TABLE `shop`
  ADD PRIMARY KEY (`ShopId`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`SupplierId`);

--
-- Indexes for table `warehouse`
--
ALTER TABLE `warehouse`
  ADD PRIMARY KEY (`WareHouseId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `receipt`
--
ALTER TABLE `receipt`
  MODIFY `S/No` int(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `requistion`
--
ALTER TABLE `requistion`
  MODIFY `S/No` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `issue`
--
ALTER TABLE `issue`
  ADD CONSTRAINT `partno_pk` FOREIGN KEY (`PartNo`) REFERENCES `itemsentry` (`PartNo`);

--
-- Constraints for table `itemsentry`
--
ALTER TABLE `itemsentry`
  ADD CONSTRAINT `warehouse_fk` FOREIGN KEY (`WarehouseId`) REFERENCES `warehouse` (`WareHouseId`);

--
-- Constraints for table `receipt`
--
ALTER TABLE `receipt`
  ADD CONSTRAINT `Issue_fk` FOREIGN KEY (`IssueVoucherNo`) REFERENCES `issue` (`IssueVoucherNo`);

--
-- Constraints for table `requistion`
--
ALTER TABLE `requistion`
  ADD CONSTRAINT `partno_fk` FOREIGN KEY (`PartNo`) REFERENCES `itemsentry` (`PartNo`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
